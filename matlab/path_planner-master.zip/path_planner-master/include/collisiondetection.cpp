#include "collisiondetection.h"

CollisionDetection::CollisionDetection()
{

}

